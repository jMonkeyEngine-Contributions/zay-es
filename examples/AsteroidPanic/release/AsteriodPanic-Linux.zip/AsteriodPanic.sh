#!/bin/sh
java  -jar AsteriodPanic.jar
        